/*avlt.h*/

//
// Threaded AVL tree
//

#pragma once

#include <iostream>
#include <vector>
#include <stack>

using namespace std;

template<typename KeyT, typename ValueT>
class avlt
{
private:
  struct NODE
  {
    KeyT   Key;
    ValueT Value;
    NODE*  Left;
    NODE*  Right;
    bool   isThreaded; // true => Right is a thread, false => non-threaded
    int    Height;     // height of tree rooted at this node
  };

  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size;  // # of nodes in the tree (0 if empty)
  NODE* Next;  // used in begin() and next() functions
  
  void inorder(NODE* cur, ostream& output) const{
	  // base case
	  if(cur == nullptr)
	  return;
	  
	  // go left
	  inorder(cur->Left, output);
	  // output depending on if the node is threaded or not
	  // does else output if outputing the very last element of inorder traversal
		if(cur->isThreaded && cur->Right)
			output << "(" << cur->Key << "," << cur->Value << "," << cur->Height << "," << cur->Right->Key << ")" << endl;
		
		else
			output << "(" << cur->Key << "," << cur->Value << "," << cur->Height  << ")" << endl;
		
		// go right if the right pointer is not pointing to
		// an already visited node
		  if(!cur->isThreaded)
			  inorder(cur->Right, output);
	  
  }
  //
  // recursive function for postorder destroyer of a tree
  //
  void _destroy(NODE* cur){
  if(cur != nullptr){
    _destroy(cur->Left);
	if(!cur->isThreaded)
		_destroy(cur->Right);
	
	delete cur;
	Size--;
    }
  }
  
  //
  // recursive range_search functio, iterates the tree inorder
  //
  void _range_search(NODE* cur, vector<KeyT>& keys, KeyT lower, KeyT upper){
	  // base case
	  if(cur == nullptr){
		  return;
	  }
	  // check left
	  if(cur->Key > lower){
		  _range_search(cur->Left, keys, lower, upper);
	  }
	  // push into the vector if value is in range
	  if(lower <= cur->Key && cur->Key <= upper){
		  keys.push_back(cur->Key);
	  }
	  // check right if cur is not threaded
	  if(cur->Key < upper && !cur->isThreaded){
		  _range_search(cur->Right, keys, lower, upper);
	  }
  }
  
  //
  // this is an insert function for copy constructor
  // it doesn't rebalance the tree. it does update the heights
  //
  void _insert(KeyT key, ValueT value)
  {
    //
    // TODO
    //
    
	NODE* prev = nullptr;
    NODE* cur = Root;
	bool insertRight = false; // this will let us know if we need to use prev or cur
	vector<NODE*> nodes;

    //
    // 1. Search to see if tree already contains key:
    //
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;

	  nodes.push_back(cur);
      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = cur->Left;
      }
      else if (key > cur->Key && cur->isThreaded){    
		  insertRight = true;   // insert here
		  break;
	  }
		  
	  else
      {
        prev = cur;
        cur = cur->Right;  // search right
      }
	  
    }//while
	
    //
    // 2. if we get here, key is not in tree, so allocate
    // a new node to insert:
    // 

    //
    // TODO: allocate a new node, store key, initialize
    // pointer fields:
    //
    
    NODE* temp = new NODE;
    
    temp->Key = key;
	temp->Value = value;
	temp->Height = 0;
    temp->Left = nullptr;
    temp->Right = nullptr;
	temp->isThreaded = false;
    
    
    
    //
    // 3. link in the new node:
    //
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.
    // 


	if(insertRight){ // if we already know that we need to insert on the right use cur
		temp->Right = cur->Right; // thread inheritance
		cur->Right = temp; // assigning 
		cur->isThreaded = false; 
		temp->isThreaded = true;
	}
	else if(prev == nullptr){ // tree is empty, 
		Root = temp;
		Root->isThreaded = true;
	}
	else if(key < prev->Key){ // insert left
		temp->Right = prev;
		temp->isThreaded = true;
		prev->Left = temp;
	}
	

    // 
    // 4. update size and we're done:
    //
    
    Size++;
	
	// 5. walk back up tree using stack and update heights:
    //
    // while (nodes is not empty)
    //{
    //  let cur be the top element;
    //  pop the stack;
    //
    //  let HL = height of cur's left sub-tree (-1 if empty);
    //  let HR = height of cur's right sub-tree (-1 if empty);
    //  let newH = 1 + max(HL, HR);
    //
    //  cur's new height = newH;
    //}
    
    while(!nodes.empty()){
       cur = nodes.back();
       nodes.pop_back();
       
       int HL;
       int HR;
       if (cur->Left == nullptr)
       HL = -1;
       else 
       HL = cur->Left->Height;
       
       if (cur->Right == nullptr || cur->isThreaded)
       HR = -1;
       else 
       HR = cur->Right->Height;
       int newH = 1 + max(HL, HR);
       
       cur->Height = newH;
    }
  }
  
  //
  // recursive copy function
  //
  // iterates through each node in other tree in preorder
  // and inserting the element in this tree using insert()
  //
  void _copy(NODE* cur){
	  if(cur != nullptr){
		  _insert(cur->Key, cur->Value);
		  _copy(cur->Left);
		  if(!cur->isThreaded)
		  _copy(cur->Right);
	  }
  }
  
  //
  // regular RightRotate function
  // rotates the nodes in a tree
  //
  void _RightRotate(NODE* Parent, NODE* N)
  {
	 // name the nodes the same way as in lecture notes
     NODE* L = N->Left;
     NODE* A = L->Left;
	 
	 // make sure we dont get a thread instead of a nullptr
	 NODE* B;
	 if(!L->isThreaded){
		 B = L->Right;
	 }
	 else{ 
		 B = nullptr;
	 }
	 
	 // make sure we dont get a thread instead of a nullptr
	 NODE* C;
	 if(!N->isThreaded){
		 C = N->Right;
	 }
	 else{
		 C = nullptr;
	 }
     
	 // rotate
     L->Right = N;
     N->Left = B;
	 
	 // update the thread
	 L->isThreaded = false;
     
	 // link in L
     if(Parent == nullptr){
		 Root = L;
	 }
     else if(Parent->Right == N){
		 Parent->Right = L;
	 }
     else{
		 Parent->Left = L;
     }
	 
	 // calculate the heights
     int HA, HB, HC;
     if(A == nullptr)
     HA = -1;
     else 
     HA = A->Height;
	 
	      
     if(B == nullptr)
     HB = -1;
     else 
     HB = B->Height;
	 
     
     if(C == nullptr)
     HC = -1;
     else 
     HC = C->Height;
     
     // update the heights
     N->Height = max(HB, HC) + 1;
     L->Height = max(HA, N->Height) + 1;
  }
  
  //
  // regular LeftRotate function
  //
  void _LeftRotate(NODE* Parent, NODE* N)
  {
	 // name the nodes as in lecture notes
     NODE* R = N->Right;
     NODE* A = N->Left;
     NODE* B = R->Left;
	 
	 // make sure we dont get a thread instead of a nullptr
	 NODE* C;
	 if(!R->isThreaded)
     C = R->Right;
	 else
	 C = nullptr;
     
	 // rotate
     R->Left = N;
     N->Right = B;
     
	 // link in R
     if(Parent == nullptr){
        Root = R;
     }
     else if(Parent->Right == N){
        Parent->Right = R;
     }
     else{
        Parent->Left = R;
     }
     
	 // calculate the heights
     int HA, HB, HC;
     if(A == nullptr)
     HA = -1;
     else 
     HA = A->Height;
	 
	 if(HA == 0){
		 A->Right = N;
		 A->isThreaded = true;
	 }
     
     if(B == nullptr)
     HB = -1;
     else 
     HB = B->Height;
	 
	 if(HB == -1){
		 N->Right = R;
		 N->isThreaded = true;
	 }
     
     if(C == nullptr)
     HC = -1;
     else
     HC = C->Height;
     
	 // update the heights
     N->Height = max(HA, HB) + 1;
     R->Height = max(N->Height, HC) + 1;  
  }

public:
  //
  // default constructor:
  //
  // Creates an empty tree.
  //
  avlt()
  {
    Root = nullptr;
    Size = 0;
	Next = nullptr;
  }

  //
  // copy constructor
  //
  // NOTE: makes an exact copy of the "other" tree, such that making the
  // copy requires no rotations.
  //
  avlt (const avlt& other)
  {
	Size = 0;
	Next = nullptr;
	Root = nullptr;
	this->_copy(other.Root);
  }

  //
  // destructor:
  //
  // Called automatically by system when tree is about to be destroyed;
  // this is our last chance to free any resources / memory used by
  // this tree.
  //
  virtual ~avlt()
  {
	_destroy(Root);
  }

  //
  // operator=
  //
  // Clears "this" tree and then makes a copy of the "other" tree.
  //
  // NOTE: makes an exact copy of the "other" tree, such that making the
  // copy requires no rotations.
  //
  avlt& operator=(const avlt& other)
  {
	this->clear();
	this->_copy(other.Root);
    return *this;
  }

  //
  // clear:
  //
  // Clears the contents of the tree, resetting the tree to empty.
  //
  void clear()
  {
	_destroy(Root);
	Root = nullptr;
	Size = 0;
	Next = nullptr;
  }

  // 
  // size:
  //
  // Returns the # of nodes in the tree, 0 if empty.
  //
  // Time complexity:  O(1) 
  //
  int size() const
  {
    return Size;
  }

  // 
  // height:
  //
  // Returns the height of the tree, -1 if empty.
  //
  // Time complexity:  O(1) 
  //
  int height() const
  {
    if (Root == nullptr)
      return -1;
    else
      return Root->Height;
  }

  // 
  // search:
  //
  // Searches the tree for the given key, returning true if found
  // and false if not.  If the key is found, the corresponding value
  // is returned via the reference parameter.
  //
  // Time complexity:  O(lgN) worst-case
  //
  bool search(KeyT key, ValueT& value) const
  {
    NODE* cur = Root;
     
     // loop until reach the end
     while(cur != nullptr){
	 
	 // if we found the key return
     if(key == cur->Key){
      value = cur->Value;  
      return true;
     }
	 // if the key is smaller than cur go left
     else if (key < cur->Key)
      cur = cur->Left;
	  
	 // if the key is greater than cur
	 // make sure we haven't reached the end
	 // if not, go right
     else {
        if(cur->isThreaded){
			cur = nullptr;
		}
		
        else
			cur = cur->Right;
     }
    }
	
    return false;
  }

  //
  // range_search
  //
  // Searches the tree for all keys in the range [lower..upper], inclusive.
  // It is assumed that lower <= upper.  The keys are returned in a vector;
  // if no keys are found, then the returned vector is empty.
  //
  // Time complexity: O(lgN + M), where M is the # of keys in the range
  // [lower..upper], inclusive.
  //
  // NOTE: do not simply traverse the entire tree and select the keys
  // that fall within the range.  That would be O(N), and thus invalid.
  // Be smarter, you have the technology.
  //
  vector<KeyT> range_search(KeyT lower, KeyT upper)
  {
    vector<KeyT>  keys;
	if(Root == nullptr){
		return keys;
	}
	else{
		_range_search(Root, keys, lower, upper);
	}
    return keys;
  }

  //
  // insert
  //
  // Inserts the given key into the tree; if the key has already been insert then
  // the function returns without changing the tree.  Rotations are performed
  // as necessary to keep the tree balanced according to AVL definition.
  //
  // Time complexity:  O(lgN) worst-case
  //
  void insert(KeyT key, ValueT value)
  {
    //
    // TODO
    //
    
	NODE* prev = nullptr;
    NODE* cur = Root;
	bool insertRight = false; // this will let us know if we need to use prev or cur
	vector<NODE*> path;
	

    //
    // 1. Search to see if tree already contains key:
    //
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;

	  path.push_back(cur);
      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = cur->Left;
      }
      else if (key > cur->Key && cur->isThreaded){    
		  insertRight = true;   // insert here
		  break;
	  }
		  
	  else
      {
        prev = cur;
        cur = cur->Right;  // search right
      }
	  
    }//while
	
    //
    // 2. if we get here, key is not in tree, so allocate
    // a new node to insert:
    // 

    //
    // TODO: allocate a new node, store key, initialize
    // pointer fields:
    //
    
    NODE* temp = new NODE();
    
	temp->Height = 0;
    temp->Key = key;
	temp->Value = value;
    temp->Left = nullptr;
    temp->Right = nullptr;
	temp->isThreaded = false;
    
    
    
    //
    // 3. link in the new node:
    //
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.
    // 


	if(insertRight){ // if we already know that we need to insert on the right use cur
		// we will reuse insertRight later to update the threads and heights.
		insertRight = false;
		if(!cur->Right){
			insertRight = true;
		}
		temp->Right = cur->Right; // thread inheritance
		cur->Right = temp; // assigning 
		cur->isThreaded = false; 
		temp->isThreaded = true;
	}
	else if(prev == nullptr){ // tree is empty, 
		insertRight = false; // used to update the threads and heights later
		Root = temp;
		Root->isThreaded = true;
	}
	else if(key < prev->Key){ // insert left
		insertRight = false; // used to update threads and the heights later
		temp->Right = prev;
		temp->isThreaded = true;
		prev->Left = temp;
	}
	

    // 
    // 4. update size and height:
    //
    
	// walk back up the tree
	while(!path.empty()){
		cur = path.back();
		path.pop_back();
		
		// calculate the heights
		int hL, hR, hCur;
		if(cur->Left == nullptr){
			hL = -1;
		}
		else{
			hL = cur->Left->Height;
		}
		
		if(cur->Right == nullptr || cur->isThreaded){
			hR = -1;
		}
		else{
			hR = cur->Right->Height;
		}
		
		// if broken and leaning to the left
		if(hL - hR > 1){
			// rebalance the tree
			// case 1
			if(cur->Left->Key > key){
				if(path.empty()) // use nullptr instead
				_RightRotate(nullptr, cur);
				else
				_RightRotate(path.back(), cur);
			}
			// case 2
			else if(cur->Left->Key < key){
				_LeftRotate(cur, cur->Left);
				if(path.empty()) // use nullptr instead
				_RightRotate(nullptr, cur);
				else
				_RightRotate(path.back(), cur);
			}
		}
		// if broken and leaning to the right
		else if(hR - hL > 1){
			// rebalance the tree
			// case 4
			if(cur->Right->Key < key){
				if(path.empty()) // use nullptr instead
				_LeftRotate(nullptr, cur);
				else
				_LeftRotate(path.back(), cur);
			}
			// case 3
			else if(cur->Right->Key > key){
				_RightRotate(cur, cur->Right);
				if(path.empty()) // use nullptr instead
				_LeftRotate(nullptr, cur);
				else
				_LeftRotate(path.back(), cur);
			}
		}
		
		hCur = 1 + std::max(hL, hR);
		
		// if this is true, we don't need to update the heights above
		if(cur->Height == hCur){
			break;
		}
		// make sure we don't update the height where we don't need to
		else if(hL - hR < 2 && hL - hR > -2){
			cur->Height = hCur;
		}
		// this makes sure we don't lose threads
		if(cur->Height == 0 && temp->Height > cur->Height && insertRight){
			cur->Right = temp;
			cur->isThreaded = true;
		}
	} 
    Size++;
  }

  //
  // []
  //
  // Returns the value for the given key; if the key is not found,
  // the default value ValueT{} is returned.
  //
  // Time complexity:  O(lgN) on average
  //
  ValueT operator[](KeyT key) const
  {
    //
    // TODO
    //
    
	NODE* cur = Root;
	
	while(cur != nullptr){
		if(key == cur->Key)
			return cur->Value; // found. return
			
		else if(key < cur->Key){ // go left
			cur = cur->Left;
		}
		else{
			if(cur->isThreaded) // reached the end 
				return ValueT{ };
				
			else
				cur = cur->Right; // go right
		}
	}

    return ValueT{ };
  }


  //
  // ()
  //
  // Finds the key in the tree, and returns the key to the "right".
  // If the right is threaded, this will be the next inorder key.
  // if the right is not threaded, it will be the key of whatever
  // node is immediately to the right.
  //
  // If no such key exists, or there is no key to the "right", the
  // default key value KeyT{} is returned.
  //
  // Time complexity:  O(lgN) worst-case
  //
  KeyT operator()(KeyT key) const
  {
    //
    // TODO
    //

	NODE* cur = Root;
	
	while(cur != nullptr){
		if(key == cur->Key){ // found
			if(cur->Right != nullptr)
				return cur->Right->Key; // if there is something to the right, return it
				
			else
				return KeyT{ }; // if we found the key, but right is empty return default value
		}
		else if(key < cur->Key){ // go left
			cur = cur->Left;
		}
		else{
			if(cur->isThreaded) // reached the end
				return KeyT{ };
			else
				cur = cur->Right; // go right
		}
	}
    return KeyT{ };
  }

  //
  // %
  //
  // Returns the height stored in the node that contains key; if key is
  // not found, -1 is returned.
  //
  // Example:  cout << tree%12345 << endl;
  //
  // Time complexity:  O(lgN) worst-case
  //
  int operator%(KeyT key) const
  {
    //
    // TODO
    //
    
	NODE* cur = Root;
     
     // loop until reach the end
     while(cur != nullptr){
	 
	 // if we found the key return
     if(key == cur->Key){  
      return cur->Height;
     }
	 // if the key is smaller than cur go left
     else if (key < cur->Key)
      cur = cur->Left;
	  
	 // if the key is greater than cur
	 // make sure we haven't reached the end
	 // if not, go right
     else {
        if(cur->isThreaded){
			cur = nullptr;
		}
		
        else
			cur = cur->Right;
     }
    }

    return -1;
  }

  //
  // begin
  //
  // Resets internal state for an inorder traversal.  After the 
  // call to begin(), the internal state denotes the first inorder
  // key; this ensure that first call to next() function returns
  // the first inorder key.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) worst-case
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  void begin()
  {
    //
    // TODO
    //
    
	if (Size > 0){ // base case for empty tree
		Next = Root;
		while(Next->Left != nullptr){ // find the leftmost element and make Cur point at it
			Next = Next->Left;
		}
	}
  }

  //
  // next
  //
  // Uses the internal state to return the next inorder key, and 
  // then advances the internal state in anticipation of future
  // calls.  If a key is in fact returned (via the reference 
  // parameter), true is also returned.
  //
  // False is returned when the internal state has reached null,
  // meaning no more keys are available.  This is the end of the
  // inorder traversal.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) worst-case
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  bool next(KeyT& key)
  {
    //
    // TODO
    //
    
	if(Next == nullptr){
		return false; // reached the end
	}
	
	if(Next->isThreaded){ // we can go right
		key = Next->Key;
		Next = Next->Right;
		return true;
	}
	else{                    // go right once and then make sure we are at the very left of subtree
		key = Next->Key;      // we will return to the subtree's root and other nodes later
		Next = Next->Right;
		while(Next->Left){
			Next = Next->Left;
		}
		return true;
	}
	
	// if the node is threaded we can go right freely
	// otherwise if the node is not threaded we need to go right 1 time
	// and then check if there is anything to the left and go there as many times as needed
	// 
	// the else condition is the only case we go left. it makes sure we won't revisit nodes
	// we have visited before, since we go right once

    return false;
  }

  //
  // dump
  // 
  // Dumps the contents of the tree to the output stream, using a
  // recursive inorder traversal.
  //
  void dump(ostream& output) const
  {
    output << "**************************************************" << endl;
    output << "********************* AVLT ***********************" << endl;

    output << "** size: " << this->size() << endl;
    output << "** height: " << this->height() << endl;

    //
    // inorder traversal, with one output per line: either 
    // (key,value,height) or (key,value,height,THREAD)
    //
    // (key,value,height) if the node is not threaded OR thread==nullptr
    // (key,value,height,THREAD) if the node is threaded and THREAD denotes the next inorder key
    //

    //
    // TODO
    //
    
	inorder(Root, output);

    output << "**************************************************" << endl;
  }
	
};

