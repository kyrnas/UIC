/*test01.cpp*/

//
// An AVL unit test based on Catch framework
//

#include <iostream>
#include <vector>
#include <algorithm>

#include "avlt.h"

#include "catch.hpp"

using namespace std;


TEST_CASE("(1) empty tree")
{
  avlt<int, int>  tree;

  REQUIRE(tree.size() == 0);
  REQUIRE(tree.height() == -1);
}


TEST_CASE("(2) case 1 at the root")
{
  avlt<int, int>  tree;

  vector<int> keys = { 100, 80, 60 };
  vector<int> heights = { 0, 1, 0 };

  for (int key : keys)
  {
    tree.insert(key, -key);
  }

  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}
	
TEST_CASE("(3) case 1 left subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {15, 10, 20, 17, 22, 13, 5, 3, 1};
  vector<int> heights {3, 2, 1, 0, 0, 0, 0, 1, 0};
		
  for (int key : keys)
  {
  	tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(4) case 1 right subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {15, 5, 30, 1, 10, 20, 40, 19, 18, 17};
  vector<int> heights {3, 1, 1, 0, 0, 0, 0, 2, 1, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(5) case 2 right subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {45, 22, 71, 15, 30, 90, 58, 50, 65, 63};
  vector<int> heights {3, 1, 1, 0, 0, 0, 1, 0, 2, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(6) case 2 root"){
  avlt<int, int> tree;
		
  vector<int> keys = {45, 20, 70, 55, 90, 10, 30, 5, 15, 25, 40, 23};
  vector<int> heights {2, 2, 1, 0, 0, 1, 3, 0, 0, 1, 0, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(7) case 2 left subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {50, 30, 70, 60, 90, 20, 40, 5, 25, 27};
  vector<int> heights {3, 1, 1, 0, 0, 1, 0, 0, 2, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(8) case 3 left subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {50, 30, 70, 60, 90, 20, 40, 35, 45, 33};
  vector<int> heights {3, 1, 1, 0, 0, 0, 1, 2, 0, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(9) case 3 root"){
  avlt<int, int> tree;
		
  vector<int> keys = {50, 30, 70, 60, 90, 65};
  vector<int> heights {1, 0, 1, 2, 0, 0,};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(10) case 3 right subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {60, 50, 70, 65, 90, 30, 55, 80, 100, 77};
  vector<int> heights {3, 1, 1, 0, 1, 0, 0, 2, 0, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(11) case 4 root"){
  avlt<int, int> tree;
		
  vector<int> keys = {50, 35, 70, 60, 90, 100};
  vector<int> heights {1, 0, 2, 0, 1, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(12) case 4 right subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {50, 25, 75, 10, 60, 95, 80, 100, 105};
  vector<int> heights {3, 1, 1, 0, 0, 2, 0, 1, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}

TEST_CASE("(13) case 4 left subtree"){
  avlt<int, int> tree;
		
  vector<int> keys = {50, 25, 75, 10, 35, 60, 30, 40, 45};
  vector<int> heights {3, 1, 1, 0, 2, 0, 0, 1, 0};
		
  for (int key : keys)
  {
	  tree.insert(key, -key);
  }
		
  //
  // size and height?  after rebalance should be 1:
  //
  REQUIRE(tree.size() == keys.size());

  auto maxH = std::max_element(heights.begin(), heights.end());
  REQUIRE(tree.height() == *maxH);
  // 
  // values inserted?
  //
  int value;

  for (int key : keys)
  {
    REQUIRE(tree.search(key, value));
    REQUIRE(value == -key);
  }

  //
  // heights correct after rebalance?
  //
  for (size_t i = 0; i < keys.size(); ++i)
  {
    REQUIRE((tree % keys[i]) == heights[i]);
  }
}