/*main.cpp*/

//
// Kyr Nastahunin
// U. of Illinois, Chicago
// CS 251: Spring 2020
// 
// Project 6: hashing of DIVVY Data
// 

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <algorithm>

#include "hash.h"
#include "hashmap.h"
#include "util.h"

using namespace std;

//
// StationData
//
// struct that is used for stationsById and stationsByAbbrev
//
struct StationData
{
	string Id;
	string Abbrev;
	string FullName;
	double Latitude;
	double Longitude;
	string Capacity;
	string OnlineDate;
	
	StationData()
	{
		Id = "";
		Abbrev = "";
		FullName = "";
		Latitude = 0.0;
		Longitude = 0.0;
		Capacity = "";
		OnlineDate = "";
	}
};

//
// TripData
//
// struct that is used for tripsById
//
struct TripData
{
	string Id;
	string StartTime;
	string StopTime;
	string BikeId;
	int TripDuration;
	string FromStationId;
	string ToStationId;
	string Identifies;
	string YearOfBirth;
	
	TripData()
	{
		Id = "";
		StartTime = "";
		StopTime = "";
		BikeId = "";
		TripDuration = 0;
		FromStationId = "";
		ToStationId = "";
		Identifies = "";
		YearOfBirth = "";
	}
};

//
// DistStation
//
// struct used for "similar" and "nearby" commands
//
struct DistStation{
	double Distance;
	string Name;
	
	DistStation(){
		Distance = 0.0;
		Name = "";
	}
	
	DistStation(double distance, string name){
		Distance = distance;
		Name = name;
	}
};

//
// compareTwoDistStations
// 
// compare function that compares first by distance, looking for a smaller one
// if the distances are equal compares the names, looking to make them in alphabetic order
//
bool compareTwoDistStations(DistStation x, DistStation y){
	if(x.Distance == y.Distance){
		return x.Name < y.Name;
	}
	else{
		return x.Distance < y.Distance;
	}
}

//
// compareStationsByName
// 
// compares the Id's of stations looking for a smaller one
//
bool compareStationsByName(DistStation x, DistStation y){
	int nameX = stoi(x.Name);
	int nameY = stoi(y.Name);
	return nameX < nameY;
}

//
// string2int
// 
// Converts a string to an integer, unless string is empty, in
// which case 0 is returned.
// 
int string2int(string s)
{
	if (s == "")
		return 0;
	else
		return stoi(s);
}

//
// inputStationsData
// 
// opens the stations csv file and reads in the data
// storing it in two hashmaps
// returns the number of stations that were inserted
//
int inputStationsData(string filename, hashmap<string, StationData>& hmapId, hashmap<string, StationData>& hmapAbbrev)
{
	int NoStations = 0;
	
	ifstream  infile(filename);
	
	if (!infile.good())
	{
		cout << "**Error: unable to open '" << filename << "'..." << endl;
		return -1;
	}
	
	// file is open, start processing:
	string line;
	
	getline(infile, line);  // input and discard first row --- header row
	
	while (getline(infile, line))
	{
		stringstream s(line);
		
		string id, abbrev, fullname, latitudeStr, longitudeStr, capacity, onlinedate;
		double latitude, longitude;
		
		 
		getline(s, id, ',');
		getline(s, abbrev, ',');
		getline(s, fullname, ',');
		getline(s, latitudeStr, ',');
		getline(s, longitudeStr, ',');
		getline(s, capacity, ',');
		getline(s, onlinedate, ',');

		latitude = stod(latitudeStr);
		longitude = stod(longitudeStr);
		
		//
		// store into hash table
		// 
		StationData Sd;
		
		Sd.Id = id;
		Sd.Abbrev = abbrev;
		Sd.FullName = fullname;
		Sd.Latitude = latitude;
		Sd.Longitude = longitude;
		Sd.Capacity = capacity;
		Sd.OnlineDate = onlinedate;
		
		hmapId.insert(id, Sd, HashByStationID);
		hmapAbbrev.insert(abbrev, Sd, HashByAbbrev);
		
		NoStations++;
	}
	
	infile.close();
	
	return NoStations;  // return the number of stations we inserted
}

//
// inputTripData
// 
// inputs the data from trips csv file filling both tripsById hmap and bikesById hmap
// updates the number of bikes via reference parameters
// and returns the number of trips inserted
//
int inputTripData(string filename, hashmap<string, TripData>& hmap, hashmap<string, int>& hmapBikes, int& noBikes)
{
	int NoTrips = 0;
	
	ifstream  infile(filename);
	
	if (!infile.good())
	{
		cout << "**Error: unable to open '" << filename << "'..." << endl;
		return -1;
	}
	
	// we will use a map to store all the bikes while reading the file
	map<string, int> bikes;
	
	// file is open, start processing:
	string line;
	
	getline(infile, line);  // input and discard first row --- header row
	
	while (getline(infile, line))
	{
		stringstream s(line);
		
		string tripId, startTime, stopTime, bikeId, duration, from, to, identifies, birthyear;
		
		getline(s, tripId, ',');
		getline(s, startTime, ',');
		getline(s, stopTime, ',');
		getline(s, bikeId, ',');
		getline(s, duration, ',');
		getline(s, from, ',');
		getline(s, to, ',');
		getline(s, identifies, ',');
		getline(s, birthyear, ',');
		
		int tripDuration = stoi(duration);
		
		//
		// store into hash table
		// 
		TripData Td;
		
		Td.Id = tripId;
		Td.StartTime = startTime;
		Td.StopTime = stopTime;
		Td.BikeId = bikeId;
		Td.TripDuration = tripDuration;
		Td.FromStationId = from;
		Td.ToStationId = to;
		Td.Identifies = identifies;
		Td.YearOfBirth = birthyear;
		
		// insert the trip into hmap
		hmap.insert(tripId, Td, HashByTripId);
		// increment or initialize a number of trips by current bike
		bikes[bikeId] = bikes[bikeId] + 1;
		
		NoTrips++;
	}
	
	// use a for each loop to iterate through the map inserting data about each bike into hashmap
	for(const auto& kv : bikes){
		hmapBikes.insert(kv.first, kv.second, HashByBikeId);
		noBikes++; // update the number of bikes we have
	}
	
	infile.close();
	
	return NoTrips;  // return the number of trips
}

void helpCommand(){
	cout << "Available commands:" << endl;
	cout << " Enter a station id (e.g. 341)" << endl;
	cout << " Enter a station abbreviation (e.g. Adler)" << endl;
	cout << " Enter a trip id (e.g. Tr10426561)" << endl;
	cout << " Enter a bike id (e.g. B5218)" << endl;
	cout << " Nearby stations (e.g. nearby 41.86 -87.62 0.5)" << endl;
	cout << " Similar trips (e.g. similar Tr10424639 0.3)" << endl;
}

void commandInt(hashmap<string, StationData>& stationsById, string command){
	StationData Sd;
	if(!stationsById.search(command, Sd, HashByStationID)){
		cout << "Station not found" << endl;
		return;
	}
	cout << "Station:" << endl;
	cout << " ID: " << Sd.Id << endl;
	cout << " Abbrev: " << Sd.Abbrev << endl;
	cout << " Fullname: " << Sd.FullName << endl;
	cout << " Location: (" << Sd.Latitude << ", " << Sd.Longitude << ")" << endl;
	cout << " Capacity: " << Sd.Capacity << endl;
	cout << " Online date: " << Sd.OnlineDate << endl;
}

void commandTrip(hashmap<string, TripData>& tripsById, hashmap<string, StationData> stationsById, string command){
	TripData Tr;
	if(!tripsById.search(command, Tr, HashByTripId)){
		cout << "Trip not found" << endl;
		return;
	}
	// we will need the data about the two stations for proper output of their abbreviations and IDs
	StationData fromStation, toStation;
	// search for data about departure and arrival stations
	stationsById.search(Tr.FromStationId, fromStation, HashByStationID);
	stationsById.search(Tr.ToStationId, toStation, HashByStationID);
	cout << "Trip:" << endl;
	cout << " ID: " << Tr.Id << endl;
	cout << " Starttime: " << Tr.StartTime << endl;
	cout << " Bikeid: " << Tr.BikeId << endl;
	cout << " Duration: ";
	// properly format the time output
	int tripDuration = Tr.TripDuration;
	if((tripDuration / 3600) > 0){
		cout << (tripDuration / 3600) << " hours, ";
		while((tripDuration / 3600) != 0){
			tripDuration -= 3600;
		}
	}
	if((tripDuration / 60) > 0){
		cout << (tripDuration / 60) << " minutes, ";				
		while((tripDuration / 60) != 0){
			tripDuration -= 60;
		}
	}
	cout << tripDuration << " seconds";
	cout << endl;
	cout << " From station: " << fromStation.Abbrev << " (" << Tr.FromStationId << ")" << endl;
	cout << " To station: " << toStation.Abbrev << " (" << Tr.ToStationId << ")" << endl;
	cout << " Rider identifies as: " << Tr.Identifies << endl;
	cout << " Birthyear: " << Tr.YearOfBirth << endl;
}

void commandBike(hashmap<string, int>& bikesById, string command){
	int usage;
	if(!bikesById.search(command, usage, HashByBikeId)){
		cout << "Bike not found" << endl;
		return;
	}
	cout << "Bike:" << endl;
	cout << " ID: " << command << endl;
	cout << " Usage: " << usage << endl;
}

void commandNearby(hashmap<string, StationData>& stationsById, string command){
	// get data about all stations as a vector, so we could go through it all
	vector<StationData> stations = stationsById.getAsVector();
			
	// get the parameters from user input
	stringstream s(command);
	string longi, lat, rangeS;
	getline(s, lat, ' '); // get the word "nearby" and discard it
	getline(s, lat, ' '); // get the latitude
	double latitude = stod(lat);
	getline(s, longi, ' '); // get the longitude				
	double longitude = stod(longi);
	getline(s, rangeS, ' ');
	double range = stod(rangeS);
	cout << "Stations within " << rangeS << " miles of (" << lat << ", " << longi << ")" << endl;
	// we will use a vector of stations with all calculated distances to user given coordinates
	vector<DistStation> stationsWithDistances;
	for(size_t i = 0; i < stations.size(); i++){
		// generate an output-ready name 
		string name = "station " + stations[i].Id;
		// calculate distance from user coordinates to current station
		double distance = distBetween2Points(latitude, longitude, stations[i].Latitude, stations[i].Longitude);
		DistStation temp(distance, name);
		if(distance <= range){
			stationsWithDistances.push_back(temp);
		}
	}
	// check if we found any matches
	if(stationsWithDistances.size() < 1){
		cout << " none found" << endl;
	}
	else{
		// sort the vector for output, using created compare function
		sort(stationsWithDistances.begin(), stationsWithDistances.end(), compareTwoDistStations);
		for(size_t i = 0; i < stationsWithDistances.size(); i++){
			cout << " " << stationsWithDistances[i].Name << ": " << stationsWithDistances[i].Distance << " miles" << endl;
		}
	}
}

void commandSimilar(hashmap<string, StationData>& stationsById, hashmap<string, TripData>& tripsById, string command){
	// get the data about stations
	vector<StationData> stations = stationsById.getAsVector();
			
	// get the command parameters
	stringstream s(command);
	string temp;
	string tripId;
	getline(s, temp, ' '); // get the word "similar" and discard it
	getline(s, tripId, ' '); // get the tripId
	getline(s, temp, ' ');
	double range = stod(temp);
			
	// lookup the trip inputed by user
	TripData Tr;
	bool success = tripsById.search(tripId, Tr, HashByTripId);
	StationData startStation, endStation;
	cout << "Trips that follow a similar path (+/-" << temp << " miles) as " << tripId << endl;
	// make sure that this trip exists
	if(!success){
		cout << " no such trip" << endl;
		return;
	}
	// search for start and end stations, to get their coordinates
	stationsById.search(Tr.FromStationId, startStation, HashByStationID);
	stationsById.search(Tr.ToStationId, endStation, HashByStationID);
	// we will use two vectors to store all the stations that are in range for start and finish
	vector<DistStation> startStations;
	vector<DistStation> endStations;
	for(size_t i = 0; i < stations.size(); i++){
		// calculate the distances between current station and the one from trip data
		double startDistance = distBetween2Points(startStation.Latitude, startStation.Longitude, stations[i].Latitude, stations[i].Longitude);
		double finishDistance = distBetween2Points(endStation.Latitude, endStation.Longitude, stations[i].Latitude, stations[i].Longitude);
		// push_back the stations if they are within the given range and we can use them to lookup other similar trips
		if(startDistance < range){
			DistStation temp(startDistance, stations[i].Id);
			startStations.push_back(temp);
		}
		if(finishDistance < range){
			DistStation temp(finishDistance, stations[i].Id);
			endStations.push_back(temp);
		}
	}
	// sort the two vectors using the compare function defined before
	sort(startStations.begin(), startStations.end(), compareStationsByName);
	sort(endStations.begin(), endStations.end(), compareStationsByName);
	// convert the vectors with start and end stations into hashmaps to avoid nested loops
	hashmap<string, DistStation> startStationsHMAP(2000);
	hashmap<string, DistStation> endStationsHMAP(2000);
	// output the starting points and insert them into the created hashmaps
	cout << " nearby starting points: ";
	for(size_t i = 0; i < startStations.size(); i++){
		cout << startStations[i].Name << " ";
		startStationsHMAP.insert(startStations[i].Name, startStations[i], HashByStationID);
	}
	cout << endl;
	// output the ending points and insert them into the created hashmaps
	cout << " nearby ending points: ";
	for(size_t i = 0; i < endStations.size(); i++){
		cout << endStations[i].Name << " ";
		endStationsHMAP.insert(endStations[i].Name, endStations[i], HashByStationID);
	}
	cout << endl;
	int tripCount = 0;
	vector<TripData> trips = tripsById.getAsVector();
	// linearly search all the trips. If their start and end stations are in the created hashmaps increment the tripCount
	for(size_t i = 0; i < trips.size(); i++){
		DistStation Ds;
		if(startStationsHMAP.search(trips[i].FromStationId, Ds, HashByStationID) && 
		   endStationsHMAP.search(trips[i].ToStationId, Ds, HashByStationID)){
			tripCount++;
		}
	}
	cout << " trip count: " << tripCount << endl;
}

void commandAbbrev(hashmap<string, StationData> stationsByAbbrev, string command){
	StationData Sd;
	if(!stationsByAbbrev.search(command, Sd, HashByAbbrev)){
		cout << "Station not found" << endl;
		return;
	}
		cout << "Station:" << endl;
		cout << " ID: " << Sd.Id << endl;
		cout << " Abbrev: " << Sd.Abbrev << endl;
		cout << " Fullname: " << Sd.FullName << endl;
		cout << " Location: (" << Sd.Latitude << ", " << Sd.Longitude << ")" << endl;
		cout << " Capacity: " << Sd.Capacity << endl;
		cout << " Online date: " << Sd.OnlineDate << endl;
}

int main()
{
	cout << "** DIVVY analysis program **" << endl;
	cout << endl;

	// allocate all the hashmaps we need for this program
	hashmap<string, StationData> stationsById(10000);
	hashmap<string, StationData> stationsByAbbrev(10000);
	hashmap<string, TripData> tripsById(2500000);
	hashmap<string, int> bikesById(50000);

	string filename;
	
	// get the name for stations, if user enters an empty line, a default file will be used
	string filename1 = "stations.csv";
	cout << "Enter stations file> ";
	getline(cin,filename);
	if(filename != ""){
		filename1 = filename;
	}
	
	// get the name for trips, if user enters an empty line, a default file will be used
	string filename2 = "trips.csv";
	cout << "Enter trips file> ";
	getline(cin,filename);
	if(filename != ""){
		filename2 = filename;
	}
	cout << endl;
	
	// input the stations data into two hashmaps
	cout << "Reading " << filename1 << endl;
	int noStations = inputStationsData(filename1, stationsById, stationsByAbbrev);
	
	// input the trips and bike data into two hashmaps
	cout << "Reading " << filename2 << endl;
	int noBikes = 0;
	int noTrips = inputTripData(filename2, tripsById, bikesById, noBikes);
	
	// give the basic statistic
	cout << endl;
	cout << "# of stations: " << noStations << endl;
	cout << "# of trips: " << noTrips << endl;
	cout << "# of bikes: " << noBikes << endl;
	
	// ask for user input
	string command;
	cout << endl;
	cout << "Please enter a command, help, or #> ";
	getline(cin, command);

	//
	// user testing:
	//
	while (command != "#")
	{
		if(command == "help"){ // the help command
			helpCommand();
		}
		else if(isNumeric(command)){ // the search by id command
			commandInt(stationsById, command);
		}
		else if(command.substr(0,2) == "Tr" && isNumeric(command.substr(2, (command.length()-1)))){ // the search by trip command
			commandTrip(tripsById, stationsById, command);
		}
		else if(command.substr(0,1) == "B" && isNumeric(command.substr(1, (command.length()-1)))){ // command for getting information about a specific bike
			commandBike(bikesById, command);
		}
		else if(command.substr(0,6) == "nearby"){ // command for finding nearby stations
			commandNearby(stationsById, command);
		}
		else if(command.substr(0,7) == "similar"){ // similar
			commandSimilar(stationsById, tripsById, command);
		}
		else{ // search station by abbrev
			commandAbbrev(stationsByAbbrev, command);
		}
		
		// ask for user input again
		cout << endl;
		cout << "Please enter a command, help, or #> ";
		getline(cin, command);
	}
	
	//
	// done!
	// 
	return 0;
}
