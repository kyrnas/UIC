/*hash.cpp*/

//
// Kyr Nastahunin
// U. of Illinois, Chicago
// CS 251: Spring 2020
// 
 

#include <iostream>
#include <string>
#include <cctype>  /*isdigit*/
#include <regex>   /*regular expressions*/

#include "hash.h"

using namespace std;

//
// isNumeric
//
// Returns true if the given string is numeric (all digits), false
// if not.  If the string is empty, false is returned since there 
// are no digits present.
//
bool isNumeric(string s)
{
	//
	// A string is numeric if it contains 1 or more digits, so let's
	// use a regular expression to check that.
	//
	// we are using POSIX basic notation for regular expressions, see
	//   https://en.cppreference.com/w/cpp/regex/ecmascript
	// where [:d:] means digit, [[:d:]] means match a single digit.
	// The + means match the preceding sub-expression 1 or more times.
	//
	regex pattern("[[:d:]]+", regex::ECMAScript);

	smatch matchResults;  // provides more details on the match

	if (regex_match(s, matchResults, pattern))
		return true;
	else
		return false;
}

int HashByStationID(string id, int N){
	if(!isNumeric(id)){
		return -1;
	}
	else{
		int result = stoi(id);
		return result % N;
	}
}

int HashByAbbrev(string abbrev, int N){
	int result = 0;
	for(size_t i=0; i<abbrev.length(); i++){
		result += ((i + 40) * 5) * abbrev[i];
	}
	return result % N;
}

int HashByTripId(string tripid, int N){
	if(tripid.substr(0, 2) != "Tr"){
		return -1;
	}
	tripid.erase(0, 2);
	if(!isNumeric(tripid) || tripid.length() == 0){
		return -1;
	}
	int result = stoi(tripid);
	return result % N;
}

int HashByBikeId(string bikeid, int N){
	if(bikeid[0] != 'B'){
		return -1;
	}
	bikeid.erase(0,1);
	if(!isNumeric(bikeid) || bikeid.length() == 0){
		return -1;
	}
	int result = stoi(bikeid);
	return result % N;
}
