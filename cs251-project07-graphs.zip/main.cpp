/*main.cpp*/

//
// Prof. Joe Hummel
// U. of Illinois, Chicago
// CS 251: Spring 2020
// Project #07: open street maps, graphs, and Dijkstra's alg
// 
// References:
// TinyXML: https://github.com/leethomason/tinyxml2
// OpenStreetMap: https://www.openstreetmap.org
// OpenStreetMap docs:  
//   https://wiki.openstreetmap.org/wiki/Main_Page
//   https://wiki.openstreetmap.org/wiki/Map_Features
//   https://wiki.openstreetmap.org/wiki/Node
//   https://wiki.openstreetmap.org/wiki/Way
//   https://wiki.openstreetmap.org/wiki/Relation
//

#include <iostream>
#include <iomanip>  /*setprecision*/
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <limits>

#include "tinyxml2.h"
#include "dist.h"
#include "osm.h"
#include "graph.h"

using namespace std;
using namespace tinyxml2;

const double INF = numeric_limits<double>::max();

class prioritize{
public:
   bool operator()(const pair<long long, double>& p1, const pair<long long, double>& p2) const{
      if(p1.second == p2.second)
         return p1.first > p2.first;
      else
         return p1.second > p2.second;
   }
};

//
// Dijkstra:
//
// Performs Dijkstra's shortest weighted path algorithm from
// the given start vertex.  Returns a vector of vertices in
// the order they were visited, along with a map of (string,int)
// pairs where the string is a vertex V and the int is the 
// distance from the start vertex to V; if no such path exists,
// the distance is INF (defined in util.h).
//
map<long long, long long> Dijkstra(graph<long long, double>& G, 
  long long startV, 
  map<long long, double>& distances)
{
  vector<long long>  visited;
  map<long long, long long> predecessors;
  vector<long long> vertices = G.getVertices();
  priority_queue<pair<long long, double>, vector<pair<long long, double>>, prioritize> unvisitedQueue;
	
  for(auto v : vertices){
     distances[v] = INF;
	 predecessors[v] = 0;
     unvisitedQueue.push(make_pair(v, INF));
  }
  
  distances[startV] = 0.0;
  unvisitedQueue.push(make_pair(startV, 0.0));
  
  while(!unvisitedQueue.empty()){
     long long currentV = unvisitedQueue.top().first;
     unvisitedQueue.pop();
     
     bool isVisited = false;
     for(long long name : visited){
      if(name == currentV)
       isVisited = true;
     }
     
     if(distances[currentV] == INF){
        break;
     }
     else if(isVisited){
        
     }
     else{
        visited.push_back(currentV);
     }
     
     set<long long> neighb = G.neighbors(currentV);
     for(long long adjV : neighb){
      double edgeWeight = INF;
      G.getWeight(currentV, adjV, edgeWeight);
      double alternativePathDistance = distances[currentV] + edgeWeight;
      
      if(alternativePathDistance < distances[adjV]){
       distances[adjV] = alternativePathDistance;
	   predecessors[adjV] = currentV;
       unvisitedQueue.push(make_pair(adjV, alternativePathDistance));
      }
     }
  }
  
  

  return predecessors;
}

void searchPath(string startBuilding, string endBuilding, vector<BuildingInfo>& Buildings, map<long long, Coordinates>& Nodes, graph<long long, double>& G, vector<FootwayInfo> Footways){
	int startIndex = -1;
	int endIndex = -1;

	for(size_t i = 0; i < Buildings.size(); i++){
		if(startBuilding == Buildings[i].Abbrev)
			startIndex = i;
		if(endBuilding == Buildings[i].Abbrev)
			endIndex = i;
		
		if(startIndex != -1 && endIndex != -1){
				break;
		}
	}
	if(startIndex == -1 || endIndex == -1){
		for(size_t i = 0; i < Buildings.size(); i++){
			if(Buildings[i].Fullname.find(startBuilding) != string::npos)
				startIndex = i;
			if(Buildings[i].Fullname.find(endBuilding) != string::npos)
				endIndex = i;

			if(startIndex != -1 && endIndex != -1){
				break;
			}
		}
	}

	if(startIndex == -1){
		cout << "Start building not found" << endl;
		return;
	}
	
	if(endIndex == -1){
		cout << "Destination building not found" << endl;
		return;
	}
	
	cout << "Starting point:" << endl;
	cout << " " << Buildings[startIndex].Fullname << endl;
	cout << " (" << Buildings[startIndex].Coords.Lat << ", " << Buildings[startIndex].Coords.Lon << ")" << endl;
	
	cout << "Destination point:" << endl;
	cout << " " << Buildings[endIndex].Fullname << endl;
	cout << " (" << Buildings[endIndex].Coords.Lat << ", " << Buildings[endIndex].Coords.Lon << ")" << endl;
	
	cout << endl;
	
	double fromMin = INF;
	double toMin = INF;
	long long fromIndex = -1;
	long long toIndex = -1;
	
	
	for(auto curFootway : Footways){
		for(long long curNode : curFootway.Nodes){
			double newFrom = distBetween2Points(Buildings[startIndex].Coords.Lat, Buildings[startIndex].Coords.Lon, Nodes[curNode].Lat, Nodes[curNode].Lon);
			double newTo = distBetween2Points(Buildings[endIndex].Coords.Lat, Buildings[endIndex].Coords.Lon, Nodes[curNode].Lat, Nodes[curNode].Lon);
			

			if(newFrom < fromMin){
				fromMin = newFrom;
				fromIndex = curNode;
			}
			if(newTo < toMin){
				toMin = newTo;
				toIndex = curNode;
			}
		}
	}
	
	cout << "Nearest start node:" << endl;
	cout << " " << fromIndex << endl;
	cout << " (" << Nodes[fromIndex].Lat << ", " << Nodes[fromIndex].Lon << ")" << endl;
	
	cout << "Nearest destination node:" << endl;
	cout << " " << toIndex << endl;
	cout << " (" << Nodes[toIndex].Lat << ", " << Nodes[toIndex].Lon << ")" << endl;
	
	cout << endl;
	
	cout << "Navigating with Dijkstra..." << endl;
	map<long long, double> distances;
	map<long long, long long> predecessors =  Dijkstra(G, fromIndex, distances);
	if(distances.at(toIndex) == INF){
		cout << "Sorry, destination unreachable" << endl;
		return;
	}
	cout << "Distance to dest: " << distances.at(toIndex) << " miles" << endl;
	
	if(startBuilding == endBuilding){
		cout << "Path: " << toIndex << endl;
		return;
	}
	
	vector<long long> outputResult;
	outputResult.push_back(toIndex);
	long long cur = predecessors[toIndex];
	while(cur != fromIndex){
		outputResult.push_back(cur);
		cur = predecessors[cur];
	}
	
	cout << "Path: " << fromIndex;
	for(size_t i = outputResult.size()-1; i > 0; i--){
		cout << "->" << outputResult[i];
	}
	cout << "->" << toIndex << endl;
}


//////////////////////////////////////////////////////////////////
//
// main
//
int main()
{
  map<long long, Coordinates>  Nodes;     // maps a Node ID to it's coordinates (lat, lon)
  vector<FootwayInfo>          Footways;  // info about each footway, in no particular order
  vector<BuildingInfo>         Buildings; // info about each building, in no particular order
  XMLDocument                  xmldoc;
  graph<long long, double> G;
  
  cout << "** Navigating UIC open street map **" << endl;
  cout << endl;
  cout << std::setprecision(8);

  string def_filename = "map.osm";
  string filename;

  cout << "Enter map filename> ";
  getline(cin, filename);

  if (filename == "")
  {
    filename = def_filename;
  }

  //
  // Load XML-based map file 
  //
  if (!LoadOpenStreetMap(filename, xmldoc))
  {
    cout << "**Error: unable to load open street map." << endl;
    cout << endl;
    return 0;
  }
  
  //
  // Read the nodes, which are the various known positions on the map:
  //
  size_t nodeCount = ReadMapNodes(xmldoc, Nodes);

  //
  // Read the footways, which are the walking paths:
  //
  size_t footwayCount = ReadFootways(xmldoc, Footways);

  //
  // Read the university buildings:
  //
  size_t buildingCount = ReadUniversityBuildings(xmldoc, Nodes, Buildings);

  //
  // Stats
  //
  assert(nodeCount == Nodes.size());
  assert(footwayCount == Footways.size());
  assert(buildingCount == Buildings.size());

  cout << endl;
  cout << "# of nodes: " << Nodes.size() << endl;
  cout << "# of footways: " << Footways.size() << endl;
  cout << "# of buildings: " << Buildings.size() << endl;


  //
  // TODO: build the graph, output stats:
  //


  for(auto curCoord : Nodes){
	  G.addVertex(curCoord.first);
  }
	
  for(FootwayInfo curFootway : Footways){
	  for(size_t i = 0; i < curFootway.Nodes.size(); i++){
		  if(i == curFootway.Nodes.size()-1){
			  
		  }
		  else{
			  double weight = distBetween2Points(Nodes[curFootway.Nodes[i]].Lat, Nodes[curFootway.Nodes[i]].Lon, Nodes[curFootway.Nodes[i+1]].Lat, Nodes[curFootway.Nodes[i+1]].Lon);
			  G.addEdge(curFootway.Nodes[i], curFootway.Nodes[i+1], weight);
			  G.addEdge(curFootway.Nodes[i+1], curFootway.Nodes[i], weight);
		  }
	  }
  }
  
	
  cout << "# of vertices: " << G.NumVertices() << endl;
  cout << "# of edges: " << G.NumEdges() << endl;
  cout << endl;

  //
  // Navigation from building to building
  //
  string startBuilding, destBuilding;

  cout << "Enter start (partial name or abbreviation), or #> ";
  getline(cin, startBuilding);

  while (startBuilding != "#")
  {
	cout << "Enter destination (partial name or abbreviation)> ";
	getline(cin, destBuilding);


	//
	// TODO: lookup buildings, find nearest start and dest nodes,
	// run Dijkstra's alg, output distance and path to destination:
	//
	
	searchPath(startBuilding, destBuilding, Buildings, Nodes, G, Footways);


	//
	// another navigation?
	//
	cout << endl;
	cout << "Enter start (partial name or abbreviation), or #> ";
	getline(cin, startBuilding);
  }

  //
  // done:
  //
  cout << "** Done **" << endl;

  return 0;
}
