/*bstt.h*/

//
// Threaded binary search tree
//

#pragma onc 

#include <iostream>

using namespace std;

template<typename KeyT, typename ValueT>
class bstt
{
private:
  struct NODE
  {
    KeyT   Key;
    ValueT Value;
    NODE*  Left;
    NODE*  Right;
    bool   isThreaded;
  };

  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size;  // # of nodes in the tree (0 if empty)
  NODE* Cur; // used for begin() and next() functions as an iterator


  // 
  // recursive destructor function
  //  
  // interates through the tree in postoreder deleting the nodes
  // and decreasing the size
  // 
  void _destroy(NODE* cur){
  if(cur != nullptr){
    _destroy(cur->Left);
	if(!cur->isThreaded)
		_destroy(cur->Right);
	
	delete cur;
	Size--;
    }
  }
  
  //
  // recursive copy function
  //
  // iterates through each node in other tree in preorder
  // and inserting the element in this tree using insert()
  //
  void _copy(NODE* cur){
	  if(cur != nullptr){
		  insert(cur->Key, cur->Value);
		  _copy(cur->Left);
		  if(!cur->isThreaded)
		  _copy(cur->Right);
	  }
  }


  //
  // recursive function for dump()
  // 
  // traverses inorder through the tree outputing the values
  // 
  void inorder(NODE* cur, ostream& output) const{
	  // base case
	  if(cur == nullptr)
	  return;
	  
	  // go left
	  inorder(cur->Left, output);
	  // output depending on if the node is threaded or not
	  // does else output if outputing the very last element of inorder traversal
		if(cur->isThreaded && cur->Right)
			output << "(" << cur->Key << "," << cur->Value << "," << cur->Right->Key << ")" << endl;
		
		else
			output << "(" << cur->Key << "," << cur->Value << ")" << endl;
		
		// go right if the right pointer is not pointing to
		// an already visited node
		  if(!cur->isThreaded)
			  inorder(cur->Right, output);
	  
  }
  

public:
  //
  // default constructor:
  //
  // Creates an empty tree.
  //
  bstt()
  {
    Root = nullptr;
    Size = 0;
	Cur = nullptr;
  }

  //
  // copy constructor
  //
  bstt(const bstt& other)
  {
    //
    // TODO
    //
    
	Size = 0;
	Cur = nullptr;
	Root = nullptr;
	this->_copy(other.Root);
	
  }

  //
  // destructor:
  //
  // Called automatically by system when tree is about to be destroyed;
  // this is our last chance to free any resources / memory used by
  // this tree.
  //
  virtual ~bstt()
  {
    //
    // TODO
    //
    
	_destroy(Root);
  }

  //
  // operator=
  //
  // Clears "this" tree and then makes a copy of the "other" tree.
  //
  bstt& operator=(const bstt& other)
  {
    //
    // TODO:
    //
    
	this->clear();
	
	this->_copy(other.Root);
	
    return *this;
  }

  //
  // clear:
  //
  // Clears the contents of the tree, resetting the tree to empty.
  //
  void clear()
  {
    //
    // TODO
    //
    
	_destroy(Root);
	Root = nullptr;
	Size = 0;
	Cur = nullptr;
  }

  // 
  // size:
  //
  // Returns the # of nodes in the tree, 0 if empty.
  //
  // Time complexity:  O(1) 
  //
  int size() const
  {
    return Size;
  }

  // 
  // search:
  //
  // Searches the tree for the given key, returning true if found
  // and false if not.  If the key is found, the corresponding value
  // is returned via the reference parameter.
  //
  // Time complexity:  O(lgN) on average
  //
  bool search(KeyT key, ValueT& value) const
  {
    //
    // TODO
    //
    
	NODE* cur = Root;
     
     // loop until reach the end
     while(cur != nullptr){
	 
	 // if we found the key return
     if(key == cur->Key){
      value = cur->Value;  
      return true;
     }
	 // if the key is smaller than cur go left
     else if (key < cur->Key)
      cur = cur->Left;
	  
	 // if the key is greater than cur
	 // make sure we haven't reached the end
	 // if not, go right
     else {
        if(cur->isThreaded){
			cur = nullptr;
		}
		
        else
			cur = cur->Right;
     }
    }
	return false;
  }

  //
  // insert
  //
  // Inserts the given key into the tree; if the key has already been insert then
  // the function returns without changing the tree.
  //
  // Time complexity:  O(lgN) on average
  //
  void insert(KeyT key, ValueT value)
  {
    //
    // TODO
    //
    
	NODE* prev = nullptr;
    NODE* cur = Root;
	bool insertRight = false; // this will let us know if we need to use prev or cur

    //
    // 1. Search to see if tree already contains key:
    //
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;

      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = cur->Left;
      }
      else if (key > cur->Key && cur->isThreaded){    
		  insertRight = true;   // insert here
		  break;
	  }
		  
	  else
      {
        prev = cur;
        cur = cur->Right;  // search right
      }
	  
    }//while
	
    //
    // 2. if we get here, key is not in tree, so allocate
    // a new node to insert:
    // 

    //
    // TODO: allocate a new node, store key, initialize
    // pointer fields:
    //
    
    NODE* temp = new NODE;
    
    temp->Key = key;
	temp->Value = value;
    temp->Left = nullptr;
    temp->Right = nullptr;
	temp->isThreaded = false;
    
    
    
    //
    // 3. link in the new node:
    //
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.
    // 


	if(insertRight){ // if we already know that we need to insert on the right use cur
		temp->Right = cur->Right; // thread inheritance
		cur->Right = temp; // assigning 
		cur->isThreaded = false; 
		temp->isThreaded = true;
	}
	else if(prev == nullptr){ // tree is empty, 
		Root = temp;
		Root->isThreaded = true;
	}
	else if(key < prev->Key){ // insert left
		temp->Right = prev;
		temp->isThreaded = true;
		prev->Left = temp;
	}
	

    // 
    // 4. update size and we're done:
    //
    
    Size++;
  }

  //
  // []
  //
  // Returns the value for the given key; if the key is not found,
  // the default value ValueT{} is returned.
  //
  // Time complexity:  O(lgN) on average
  //
  ValueT operator[](KeyT key) const
  {
    //
    // TODO
    //
    
	NODE* cur = Root;
	
	while(cur != nullptr){
		if(key == cur->Key)
			return cur->Value; // found. return
			
		else if(key < cur->Key){ // go left
			cur = cur->Left;
		}
		else{
			if(cur->isThreaded) // reached the end 
				return ValueT{ };
				
			else
				cur = cur->Right; // go right
		}
	}

    return ValueT{ };
  }

  //
  // ()
  //
  // Finds the key in the tree, and returns the key to the "right".
  // If the right is threaded, this will be the next inorder key.
  // if the right is not threaded, it will be the key of whatever
  // node is immediately to the right.
  //
  // If no such key exists, or there is no key to the "right", the
  // default key value KeyT{} is returned.
  //
  // Time complexity:  O(lgN) on average
  //
  KeyT operator()(KeyT key) const
  {
    //
    // TODO
    //
    
	NODE* cur = Root;
	
	while(cur != nullptr){
		if(key == cur->Key){ // found
			if(cur->Right != nullptr)
				return cur->Right->Key; // if there is something to the right, return it
				
			else
				return KeyT{ }; // if we found the key, but right is empty return default value
		}
		else if(key < cur->Key){ // go left
			cur = cur->Left;
		}
		else{
			if(cur->isThreaded) // reached the end
				return KeyT{ };
			else
				cur = cur->Right; // go right
		}
	}
	
    return KeyT{ };
  }

  //
  // begin
  //
  // Resets internal state for an inorder traversal.  After the 
  // call to begin(), the internal state denotes the first inorder
  // key; this ensure that first call to next() function returns
  // the first inorder key.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) on average
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  void begin()
  {
    //
    // TODO
    //
    
	if (Size > 0){ // base case for empty tree
		Cur = Root;
		while(Cur->Left != nullptr){ // find the leftmost element and make Cur point at it
			Cur = Cur->Left;
		}
	}
  }

  //
  // next
  //
  // Uses the internal state to return the next inorder key, and 
  // then advances the internal state in anticipation of future
  // calls.  If a key is in fact returned (via the reference 
  // parameter), true is also returned.
  //
  // False is returned when the internal state has reached null,
  // meaning no more keys are available.  This is the end of the
  // inorder traversal.
  //
  // Space complexity: O(1)
  // Time complexity:  O(lgN) on average
  //
  // Example usage:
  //    tree.begin();
  //    while (tree.next(key))
  //      cout << key << endl;
  //
  bool next(KeyT& key)
  {
    //
    // TODO
    //
    
	if(Cur == nullptr){
		return false; // reached the end
	}
	
	if(Cur->isThreaded){ // we can go right
		key = Cur->Key;
		Cur = Cur->Right;
		return true;
	}
	else{                    // go right once and then make sure we are at the very left of subtree
		key = Cur->Key;      // we will return to the subtree's root and other nodes later
		Cur = Cur->Right;
		while(Cur->Left){
			Cur = Cur->Left;
		}
		return true;
	}
	
	// if the node is threaded we can go right freely
	// otherwise if the node is not threaded we need to go right 1 time
	// and then check if there is anything to the left and go there as many times as needed
	// 
	// the else condition is the only case we go left. it makes sure we won't revisit nodes
	// we have visited before, since we go right once

    return false;
  }
  

  //
  // dump
  // 
  // Dumps the contents of the tree to the output stream, using a
  // recursive inorder traversal.
  //
  void dump(ostream& output) const
  {
    output << "**************************************************" << endl;
    output << "********************* BSTT ***********************" << endl;

    output << "** size: " << this->size() << endl;

    //
    // inorder traversal, with one output per line: either 
    // (key,value) or (key,value,THREAD)
    //
    // (key,value) if the node is not threaded OR thread==nullptr
    // (key,value,THREAD) if the node is threaded and THREAD denotes the next inorder key
    //

    //
    // TODO
    //
	
	
	inorder(Root, output);

    output << "**************************************************" << endl;
  }
	
};
