/*test01.cpp*/

//
// Unit tests for threaded binary search tree
//

#include <iostream>
#include <vector>

#include "bstt.h"

#include "catch.hpp"

using namespace std;


TEST_CASE("(1) general test") 
{
	bstt<int, int>  tree;
	bstt<int, int>  tree2;
	

	REQUIRE(tree.size() == 0);
	tree.insert(5, 5);
	tree.insert(3, 3);
	tree.insert(4, 4);
	tree.insert(7, 7);
	tree.insert(6, 6);
	REQUIRE(tree.size() == 5);
	
	//tree.dump(cout);
	
	int searchTest;
	REQUIRE(tree.search(5, searchTest));
	REQUIRE(searchTest == 5);
	REQUIRE(tree.search(7, searchTest));
	REQUIRE(searchTest == 7);
	REQUIRE(!tree.search(8, searchTest));
	
	tree2.insert(5, 5);
	tree2.insert(3, 3);
	tree2.insert(4, 4);
	tree2.insert(7, 7);
	tree2.insert(6, 6);
	tree2.insert(2, 2);
	tree2.insert(8, 8);
	REQUIRE(tree2.size() == 7);
	
	//tree2.dump(cout);
	
	bstt<int, int> copytree(tree2);
	REQUIRE(copytree.size() == 7);
	
	//copytree.dump(cout);
	
	copytree.clear();
	REQUIRE(copytree.size() == 0);
	
	copytree = tree;
	REQUIRE(copytree.size() == 5);
	
	//copytree.dump(cout);
	
	tree.clear();
	REQUIRE(tree.size() == 0);
	REQUIRE(!tree.search(5, searchTest));
	
	searchTest = copytree[5];
	REQUIRE(searchTest == 5);
	searchTest = copytree[7];
	REQUIRE(searchTest == 7);
	searchTest = copytree[10];
	REQUIRE(searchTest == int{ });
	REQUIRE(copytree.size() == 5);
	
	searchTest = copytree(5);
	REQUIRE(searchTest == 7);
	searchTest = copytree(3);
	REQUIRE(searchTest == 4);
	searchTest = copytree(4);
	REQUIRE(searchTest == 5);
	searchTest = copytree(7);
	REQUIRE(searchTest == int{ });
	searchTest = copytree(10);
	REQUIRE(searchTest == int{ });
	REQUIRE(copytree.size() == 5);
	
	tree2.begin();
	REQUIRE(tree2.size() == 7);
	
	//while(tree2.next(searchTest))
	//	cout << searchTest << endl;
	
	tree.insert(5, 5);
	tree.insert(7, 7);
	tree.insert(8, 8);
	tree.insert(9, 9);
	tree.insert(10, 10);
	
	//tree.dump(cout);
	
	tree.clear();
	
	tree.insert(5, 5);
	tree.insert(4, 4);
	tree.insert(3, 3);
	tree.insert(2, 2);
	tree.insert(5, 5);
	tree.insert(1, 1);
	REQUIRE(tree.size() == 5);
	
	//tree.dump(cout);
	
	tree.clear();
	
	tree.insert(7, 7);
	tree.insert(5, 5);
	tree.insert(3, 3);
	tree.insert(6, 6);
	tree.insert(8, 8);
	tree.insert(12, 12);
	tree.insert(2, 2);
	tree.insert(4, 4);
	REQUIRE(tree.size() == 8);
	
	tree.begin();
	REQUIRE(tree.size() == 8);
	
	while(tree.next(searchTest))
		cout << searchTest << endl;
	
	tree.clear();
	
	tree.insert(10, 10);
	tree.insert(5, 5);
	tree.insert(20, 20);
	tree.insert(4, 4);
	tree.insert(3, 3);
	tree.insert(2, 2);
	tree.insert(7, 7);
	tree.insert(6, 6);
	
	tree.begin();
	while(tree.next(searchTest))
		cout << searchTest << endl;
	
	tree.dump(cout);
}
