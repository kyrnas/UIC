//
// A symtable unit test based on Catch framework
// 
// Kyr Nastahunin
// U. of Illinois, Chicago
// CS 251, Spring 2020
// Project #03: symtable
// 

#include <iostream>
#include "symtable.h"
#include "catch.hpp"

using namespace std;

TEST_CASE("(2) advanced symtable test"){
	
	symtable<string, string> table1;
	string lookupSymbol;
	symtable<string, string>::Scope curScopeTest;
	
	REQUIRE(table1.size() == 0);
	REQUIRE(table1.numscopes() == 0);
	
	REQUIRE_THROWS(table1.exitScope());
	
	table1.enterScope("global");
	REQUIRE(table1.size() == 0);
	REQUIRE(table1.numscopes() == 1);
	
	table1.insert("i", "int");
	REQUIRE(table1.size() == 1);
	REQUIRE(table1.numscopes() == 1);
	
	table1.insert("j", "int");
	table1.insert("k", "int");
	REQUIRE(table1.size() == 3);
	REQUIRE(table1.numscopes() == 1);
	
	REQUIRE(table1.lookup("i", lookupSymbol));
	REQUIRE(lookupSymbol == "int");
	REQUIRE(!table1.lookup("x", lookupSymbol));
	
	curScopeTest = table1.curScope();
	REQUIRE(curScopeTest.Name == "global");
	REQUIRE(curScopeTest.Symbols["i"] == "int");
	REQUIRE(curScopeTest.Symbols.size() == 3);
	
	table1.enterScope("inner");
	REQUIRE(table1.size() == 3);
	REQUIRE(table1.numscopes() == 2);
	REQUIRE(!table1.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::CURRENT));
	REQUIRE(table1.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::GLOBAL));
	REQUIRE(lookupSymbol == "int");
	
	table1.insert("i", "double");
	REQUIRE(table1.size() == 4);
	REQUIRE(table1.lookup("i", lookupSymbol));
	REQUIRE(lookupSymbol == "double");
	
	table1.insert("i", "long");
	REQUIRE(table1.size() == 4);
	REQUIRE(table1.lookup("i", lookupSymbol));
	REQUIRE(lookupSymbol == "long");
	REQUIRE(!table1.lookup("x", lookupSymbol));
	
	curScopeTest = table1.curScope();
	REQUIRE(curScopeTest.Symbols.size() == 1);
	REQUIRE(curScopeTest.Name == "inner");
	REQUIRE(curScopeTest.Symbols["i"] == "long");
	
	
	table1.exitScope();
	REQUIRE(table1.size() == 3);
	REQUIRE(table1.numscopes() == 1);
	REQUIRE(table1.lookup("i", lookupSymbol));
	REQUIRE(lookupSymbol == "int");
	
	REQUIRE_NOTHROW(table1.exitScope());
	REQUIRE(table1.size() == 0);
	REQUIRE(table1.numscopes() == 0);
	
	symtable<string, string> table2;
	REQUIRE(table2.size() == 0);
	REQUIRE(table2.numscopes() == 0);
	
	table2.enterScope("GLOBAL");
	table2.enterScope("scope2");
	table2.enterScope("scope3");
	table2.enterScope("scope4");
	REQUIRE(table2.numscopes() == 4);
	REQUIRE(table2.size() == 0);
	
	table2.exitScope();
	table2.exitScope();
	table2.enterScope("scope3");
	table2.enterScope("scope4");
	table2.enterScope("scope5");
	table2.insert("i", "int");
	table2.insert("k", "int");
	table2.insert("haha", "string");
	table2.insert("haha2", "string");
	table2.enterScope("scope6");
	table2.enterScope("scope7");
	table2.insert("y", "int");
	table2.insert("x", "int");
	table2.insert("z", "int");
	table2.enterScope("scope8");
	table2.enterScope("scope9");
	
	REQUIRE(table2.size() == 7);
	REQUIRE(table2.numscopes() == 9);
	
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	REQUIRE(table2.size() == 4);
	REQUIRE(table2.numscopes() == 6);
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	REQUIRE_THROWS(table2.exitScope());
	
	REQUIRE(table2.size() == 0);
	REQUIRE(table2.numscopes() == 0);
	REQUIRE_THROWS(table2.curScope());
	
	table2.enterScope("GLOBAL");
	table2.enterScope("scope2");
	table2.enterScope("scope3");
	table2.insert("j", "double");
	table2.enterScope("scope4");
	table2.insert("j", "long");
	table2.enterScope("scope5");
	table2.enterScope("scope6");
	table2.insert("j", "int");
	table2.enterScope("scope7");
	table2.enterScope("scope8");
	
	REQUIRE(table2.size() == 3);
	REQUIRE(table2.numscopes() == 8);
	
	table2.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::ALL);
	REQUIRE(lookupSymbol == "int");
	REQUIRE(!table2.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::CURRENT));
	REQUIRE(!table2.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::GLOBAL));
	
	table2.exitScope();
	table2.exitScope();	
	REQUIRE(table2.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::CURRENT));
	REQUIRE(lookupSymbol == "int");
	REQUIRE(table2.size() == 3);
	REQUIRE(table2.numscopes() == 6);
	
	table2.exitScope();
	table2.exitScope();
	REQUIRE(table2.lookup("j", lookupSymbol, symtable<string, string>::ScopeOption::CURRENT));
	REQUIRE(lookupSymbol == "long");
	REQUIRE(table2.size() == 2);
	REQUIRE(table2.numscopes() == 4);
	
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	table2.exitScope();
	
	REQUIRE(table2.size() == 0);
	REQUIRE(table2.numscopes() == 0);
	
	table2.enterScope("GLOBAL");
	REQUIRE(table2.size() == 0);
	REQUIRE(table2.numscopes() == 1);
	table2.insert("uuu", "string");
	table2.enterScope("no2");
	REQUIRE(table2.lookup("uuu", lookupSymbol, symtable<string, string>::ScopeOption::GLOBAL));
	
	table2.exitScope();
	table2.exitScope();
	REQUIRE_THROWS(table2.exitScope());
}