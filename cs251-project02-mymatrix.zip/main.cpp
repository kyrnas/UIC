//
// Kyrylo Nastahunin
// 1/26/2020
// U. of Illinois, Chicago
// CS 251: Spring 2020
//


#include <iostream>
#include <string>

#include "mymatrix.h"

using namespace std;

bool parameterized_constructor_test(){
    mymatrix<int> A(5, 6);
    
    if (A.numrows() != 5)
        return false;
    
    for (int i = 0; i < A.numrows(); ++i){
        if (A.numcols(i) != 6)
            return false;
    }
    
    return true;
}

bool copy_constructor_test(){
    mymatrix<int> A(3 ,4);
    A(1,1) = 5;
    A(2, 3) = 8;
    A(2, 2) = 3;
    
    mymatrix<int> B(A);
    
    if (B == A)
        return true;
    else 
        return false;
}

bool growcols_test(){
    mymatrix<int> A;
    A.growcols(2, 8);
    if (A.numcols(2) != 8 || A.size() != 20)
        return false;
    else
        return true;
}

bool grow_test(){
    mymatrix<int> A;
    A.grow(5, 8);
    if (A.numrows() != 5 || A.numcols(4) != 8 || A.numcols(0) != 8 || A.size() != 40)
        return false;
    else 
        return true;
}

bool scalar_mult_test(){
    mymatrix<int>  M;
    
    M(0, 0) = 123;
    M(1, 1) = 456;
    M(2, 2) = 789;
    M(3, 3) = -99;
    
    mymatrix<int> N = M*2;
    
    if(N(0,0) != 246)
        return false;
    else if(N(1,1) != 912)
        return false;
    else if (N(2,2) != 1578)
        return false;
    else if (N(3,3) != -198)
        return false;
    else if (N(1,0) != 0)
        return false;
    else if (N(2,3) != 0)
        return false;
    else
        return true;
}

bool matrix_mult_test(){
    mymatrix<int> A(3, 2);
    mymatrix<int> B(2, 2);
    mymatrix<int> result;
    mymatrix<int> expectedResult(3, 2);
    
    A(0,0) = 4;                                // 4 8
    A(0,1) = 8;                                // 0 2
    A(1,0) = 0;                                // 1 6
    A(1,1) = 2;
    A(2,0) = 1;
    A(2,1) = 6;
    
    B(0,0) = 5;
    B(0,1) = 2;                                // 5 2
    B(1,0) = 9;                                // 9 4
    B(1,1) = 4;
    
    result = A*B;
    
    expectedResult(0,0) = 92;
    expectedResult(0,1) = 40;
    expectedResult(1,0) = 18;                     // 92 40              
    expectedResult(1,1) = 8;                      // 18  8
    expectedResult(2,0) = 59;                     // 59 26
    expectedResult(2,1) = 26;
        
    if (result == expectedResult)
        return true;
    else 
        return false;
}


int main(){
    
    int passedNo = 0;
    int failedNo = 0;
    
    if (parameterized_constructor_test())
        passedNo++;
    else
        failedNo++;
    
    if (copy_constructor_test())
        passedNo++;
    else
        failedNo++;
    
    if (growcols_test())
        passedNo++;
    else
        failedNo++;
    
    if (grow_test())
        passedNo++;
    else
        failedNo++;
    
    if (scalar_mult_test())
        passedNo++;
    else
        failedNo++;
    
    if (matrix_mult_test())
        passedNo++;
    else
        failedNo++;

    
    
    
   cout << "Number of tests passed = " << passedNo << endl;
   cout << "Number of tests failed = " << failedNo << endl;
    
   if (failedNo == 0){
       cout << "Congratulations! You finished the project!" << endl;
   }
    
    
   return 0;
}