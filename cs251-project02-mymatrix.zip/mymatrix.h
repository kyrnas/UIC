/*mymatrix.h*/

// 
// Kyrylo Nastahunin
// U. of Illinois, Chicago
// CS 251: Spring 2020
// Project #02
//

//
// mymatrix
//
// The mymatrix class provides a matrix (2D array) abstraction.
// The size can grow dynamically in both directions (rows and 
// cols).  Also, rows can be "jagged" --- i.e. rows can have 
// different column sizes, and thus the matrix is not necessarily 
// rectangular.  All elements are initialized to the default value
// for the given type T.  Example:
//
//   mymatrix<int>  M;  // 4x4 matrix, initialized to 0
//   
//   M(0, 0) = 123;
//   M(1, 1) = 456;
//   M(2, 2) = 789;
//   M(3, 3) = -99;
//
//   M.growcols(1, 8);  // increase # of cols in row 1 to 8
//
//   for (int r = 0; r < M.numrows(); ++r)
//   {
//      for (int c = 0; c < M.numcols(r); ++c)
//         cout << M(r, c) << " ";
//      cout << endl;
//   }
//
// Output:
//   123 0 0 0
//   0 456 0 0 0 0 0 0
//   0 0 789 0
//   0 0 0 -99
//

#pragma once

#include <iostream>
#include <exception>
#include <stdexcept>
#include <type_traits>

using namespace std;

template<typename T>
class mymatrix
{
private:
  struct ROW
  {
    T*  Cols;     // dynamic array of column elements
    int NumCols;  // total # of columns (0..NumCols-1)
  };

  ROW* Rows;     // dynamic array of ROWs
  int  NumRows;  // total # of rows (0..NumRows-1)

public:
  //
  // default constructor:
  //
  // Called automatically by C++ to construct a 4x4 matrix.  All 
  // elements are initialized to the default value of T.
  //
  mymatrix()
  {
    Rows = new ROW[4];  // an array with 4 ROW structs:
    NumRows = 4;

    // initialize each row to have 4 columns:
    for (int r = 0; r < NumRows; ++r)
    {
      Rows[r].Cols = new T[4];  // an array with 4 elements of type T:
      Rows[r].NumCols = 4;

      // initialize the elements to their default value:
      for (int c = 0; c < Rows[r].NumCols; ++c)
      {
        Rows[r].Cols[c] = T{};  // default value for type T:
      }
    }
  }

  //
  // parameterized constructor:
  //
  // Called automatically by C++ to construct a matrix with R rows, 
  // where each row has C columns. All elements are initialized to 
  // the default value of T.
  //
  mymatrix(int R, int C)
  {
    if (R < 1)
      throw invalid_argument("mymatrix::constructor: # of rows");
    if (C < 1)
      throw invalid_argument("mymatrix::constructor: # of cols");

    //
    // TODO
    //
    
    Rows = new ROW[R];  // an array with 4 ROW structs:
    NumRows = R;
    
    // initialize each row to have C columns:
    for(int r = 0; r < NumRows; ++r){
      Rows[r].Cols = new T[C]; // an array with C elements of type T:
      Rows[r].NumCols = C;
    
      // initialize the elements to their default value:
      for(int c = 0; c < Rows[r].NumCols; ++c){
        Rows[r].Cols[c] = T{}; // default value for type T:
      }
    }
  }


  //
  // copy constructor:
  //
  // Called automatically by C++ to construct a matrix that contains a 
  // copy of an existing matrix.  Example: this occurs when passing 
  // mymatrix as a parameter by value
  //
  //   void somefunction(mymatrix<int> M2)  <--- M2 is a copy:
  //   { ... }
  //
  mymatrix(const mymatrix<T>& other)
  {
    //
    // TODO
    //
    
    
    // allocate this matrix to be have the same number of rows as the other one
    this->Rows = new ROW[other.NumRows];
    this->NumRows = other.NumRows;
    
    // allocate each row with the same number of columns as the other one
    for(int r = 0; r < other.NumRows; ++r){
      this->Rows[r].Cols = new T[other.Rows[r].NumCols];
      this->Rows[r].NumCols = other.Rows[r].NumCols;
      
      // set each element equal to its corresponding element in the other one
      for(int c = 0; c < other.Rows[r].NumCols; ++c){
        this->Rows[r].Cols[c] = other.Rows[r].Cols[c];
      }
    }
  }


  //
  // numrows
  //
  // Returns the # of rows in the matrix.  The indices for these rows
  // are 0..numrows-1.
  //
  int numrows() const
  {
    //
    // TODO
    //

    return NumRows;
  }
  

  //
  // numcols
  //
  // Returns the # of columns in row r.  The indices for these columns
  // are 0..numcols-1.  Note that the # of columns can be different 
  // row-by-row since "jagged" rows are supported --- matrices are not
  // necessarily rectangular.
  //
  int numcols(int r) const
  {
    if (r < 0 || r >= NumRows)
      throw invalid_argument("mymatrix::numcols: row");

    //
    // TODO
    //

    return Rows[r].NumCols;
  }


  //
  // growcols
  //
  // Grows the # of columns in row r to at least C.  If row r contains 
  // fewer than C columns, then columns are added; the existing elements
  // are retained and new locations are initialized to the default value 
  // for T.  If row r has C or more columns, then all existing columns
  // are retained -- we never reduce the # of columns.
  //
  // Jagged rows are supported, i.e. different rows may have different
  // column capacities -- matrices are not necessarily rectangular.
  //
  void growcols(int r, int C)
  {
    if (r < 0 || r >= NumRows)
      throw invalid_argument("mymatrix::growcols: row");
    if (C < 1)
      throw invalid_argument("mymatrix::growcols: columns");

    //
    // TODO:
    //
    
    
    // check if the row doesn't already have more columns than user asks for
    if (Rows[r].NumCols < C){
    
      // create a new row of length C, copy values from the r row, and initialize new elemetns with default values
      T* newRow = new T[C];
      for (int i = 0; i < Rows[r].NumCols; ++i){
        newRow[i] = Rows[r].Cols[i];
      }
      for (int i = Rows[r].NumCols; i < C; ++i){
        newRow[i] = T{};
      }
      // delete the old pointer, assign it to newRow, and set its NumCols to C
      delete[] Rows[r].Cols;
      Rows[r].Cols = newRow;
      Rows[r].NumCols = C;
    }
   }

  //
  // grow
  //
  // Grows the size of the matrix so that it contains at least R rows,
  // and every row contains at least C columns.
  // 
  // If the matrix contains fewer than R rows, then rows are added
  // to the matrix; each new row will have C columns initialized to 
  // the default value of T.  If R <= numrows(), then all existing
  // rows are retained -- we never reduce the # of rows.
  //
  // If any row contains fewer than C columns, then columns are added
  // to increase the # of columns to C; existing values are retained
  // and additional columns are initialized to the default value of T.
  // If C <= numcols(r) for any row r, then all existing columns are
  // retained -- we never reduce the # of columns.
  // 
  void grow(int R, int C)
  {
    if (R < 1)
      throw invalid_argument("mymatrix::grow: # of rows");
    if (C < 1)
      throw invalid_argument("mymatrix::grow: # of cols");

    //
    // TODO:
    //
    
    
    // check if the user doesn't ask for less rows than there already is
    if(NumRows < R){
    
      // create a copy of original matrix, delete the original matrix, and create a new one with desired nubmer of rows
      mymatrix temp(*this);
      delete[] Rows;
      Rows = new ROW[R];
      NumRows = R;
      
      
      // create columns in each row and copy the values from corresponding indexes in temp matrix. Runs until reaches the end of "temp" matrix
      for (int r = 0; r < temp.NumRows; ++r){
        Rows[r].Cols = new T[temp.numcols(r)];
        Rows[r].NumCols = temp.numcols(r);
        for (int c = 0; c < Rows[r].NumCols; ++c){
          Rows[r].Cols[c] = temp.Rows[r].Cols[c];
        }
      }
      // create colums in all new rows and initialize them with default value of T
      for (int r = temp.NumRows; r < NumRows; ++r){
        Rows[r].Cols = new T[C];
        Rows[r].NumCols = C;
        for (int c = 0; c < Rows[r].NumCols; ++c){
          Rows[r].Cols[c] = T{};
        }
      }
    }
    // grow each column using growcols() function if needed
    for (int r = 0; r < NumRows; ++r){
      if (Rows[r].NumCols < C){
        growcols(r, C);
      }
    }
  }


  //
  // size
  //
  // Returns the total # of elements in the matrix.
  //
  int size() const
  {
    //
    // TODO
    //
    
    int noOfElements = 0;
    
    for(int i = 0; i < NumRows; ++i){
      noOfElements += Rows[i].NumCols;
    }
    
    return noOfElements;
  }


  //
  // at
  //
  // Returns a reference to the element at location (r, c); this
  // allows you to access the element or change it:
  //
  //    M.at(r, c) = ...
  //    cout << M.at(r, c) << endl;
  //
  T& at(int r, int c)
  {
    if (r < 0 || r >= NumRows)
      throw invalid_argument("mymatrix::at: row");
    if (c < 0 || c >= Rows[r].NumCols)
      throw invalid_argument("mymatrix::at: col");

    //
    // TODO
    //
    
    return Rows[r].Cols[c];
  }


  //
  // ()
  //
  // Returns a reference to the element at location (r, c); this
  // allows you to access the element or change it:
  //
  //    M(r, c) = ...
  //    cout << M(r, c) << endl;
  //
  T& operator()(int r, int c)
  {
    if (r < 0 || r >= NumRows)
      throw invalid_argument("mymatrix::(): row");
    if (c < 0 || c >= Rows[r].NumCols)
      throw invalid_argument("mymatrix::(): col");

    //
    // TODO
    //
    
    return Rows[r].Cols[c];
  }

  //
  // scalar multiplication
  //
  // Multiplies every element of this matrix by the given scalar value,
  // producing a new matrix that is returned.  "This" matrix is not
  // changed.
  //
  // Example:  M2 = M1 * 2;
  //
  mymatrix<T> operator*(T scalar)
  {
    mymatrix result(*this);

    //
    // TODO
    //
    
    // iterates through each element in new matrix multyplying it by "scalar"
    for (int r = 0; r < result.NumRows; ++r){
      for (int c = 0; c < result.Rows[r].NumCols; ++c){
        result.Rows[r].Cols[c] *= scalar;
      }
    }
    

    return result;
  }
  
  //
  // isRectangular
  //
  // checks if the matrix is recangular
  // returns ture if the matrix is recangular
  // returns false if the matrix is not recangular
  // 
  
  bool isRectangular(){
    int colsFirstRow = Rows[0].NumCols;
    for (int r = 0; r < NumRows; ++r){
      if(Rows[r].NumCols != colsFirstRow){
        return false;
      }
    }
    return true;
  }
  
  
  //
  // isRectangular
  //
  // checks if the matrix is recangular
  // returns ture if the matrix is recangular
  // returns false if the matrix is not recangular
  // 
  // takes in the matrix as a parameter
  //
  
  bool isRectangular(const mymatrix<T>& matrix){
    int colsFirstRow = matrix.Rows[0].NumCols;
    for (int r = 0; r < matrix.NumRows; ++r){
      if(matrix.Rows[r].NumCols != colsFirstRow){
        return false;
      }
    }
    return true;
  }


  //
  // matrix multiplication
  //
  // Performs matrix multiplication M1 * M2, where M1 is "this" matrix and
  // M2 is the "other" matrix.  This produces a new matrix, which is returned.
  // "This" matrix is not changed, and neither is the "other" matrix.
  //
  // Example:  M3 = M1 * M2;
  //
  // NOTE: M1 and M2 must be rectangular, if not an exception is thrown.  In
  // addition, the sizes of M1 and M2 must be compatible in the following sense:
  // M1 must be of size RxN and M2 must be of size NxC.  In this case, matrix
  // multiplication can be performed, and the resulting matrix is of size RxC.
  //
  mymatrix<T> operator*(const mymatrix<T>& other)
  {
    // mymatrix<T> result;

    //
    // both matrices must be rectangular for this to work:
    //

    //
    // TODO
    //
     if (!this->isRectangular())
       throw runtime_error("mymatrix::*: this not rectangular");
    
     if (!isRectangular(other))
       throw runtime_error("mymatrix::*: other not rectangular");
    
    
    

    //
    // Okay, both matrices are rectangular.  Can we multiply?  Only
    // if M1 is R1xN and M2 is NxC2.  This yields a result that is
    // R1xC2.
    // 
    // Example: 3x4 * 4x2 => 3x2
    //

    //
    // TODO
    //
    
     if (this->Rows[0].NumCols != other.NumRows)
       throw runtime_error("mymatrix::*: size mismatch");

    //
    // Okay, we can multiply:
    //

    //
    // TODO
    //
    
    
    // set the size values for the resulting matrix and create a new matrix with the given size
    int resultRows = this->NumRows;
    int resultCols = other.Rows[0].NumCols;
    mymatrix<T> result(resultRows, resultCols);
    
    // iterate through the correct elements storing the result in the "result" matrix
    for (int rows1 = 0; rows1 < this->NumRows; ++rows1){
      int sum = 0; // this will be the final number stored 
      for (int cols2 = 0; cols2 < other.NumRows; ++cols2){
        for (int cols1 = 0; cols1 < this->Rows[rows1].NumCols; ++cols1){
          sum += (this->Rows[rows1].Cols[cols1] * other.Rows[cols1].Cols[cols2]);
        }
        result(rows1, cols2) = sum;
        sum = 0;
      }
    } 

    return result;
  }
  
  //
  // matrix comparison
  // 
  // compares two matrices for difference in any parameters
  // if any difference found returns false
  // if no differences found returns true
  // 
  // created for testing purposes
  //
  
  bool operator==(const mymatrix<T> &other){
    if (this->size() != other.size())
      return false;
    if (this->NumRows != other.NumRows)
      return false;
    
    for (int r = 0; r < this->NumRows; ++r){
      if (this->Rows[r].NumCols != other.Rows[r].NumCols)
        return false;
      for (int c = 0; c <this->Rows[r].NumCols; ++c){
        if (this->Rows[r].Cols[c] != other.Rows[r].Cols[c])
          return false;
      }
    }
    return true;
  }

  //
  // _output
  //
  // Outputs the contents of the matrix; for debugging purposes.
  //
  void _output()
  {
    for (int r = 0; r < this->NumRows; ++r)
    {
      for (int c = 0; c < this->Rows[r].NumCols; ++c)
      {
        cout << this->Rows[r].Cols[c] << " ";
      }
      cout << endl;
    }
  }

};
