//
//Kyr Nastahunin
//1/17/2020
//U. of Illinois, Chicago
//CS 251: Spring 2020
//

#include <iostream>
#include <fstream>
#include <string>

#include "ourvector.h"

using namespace std;


void getCommand();
string findDomainSpam(string line);
string findAddressSpam(string line);
string findDomainEmail(string line);
string findAddressEmail(string line);
void load(string filename, ourvector<string> &myEmails);
void display(ourvector<string> &spamlist);
bool isSpam(string emailToCheck, ourvector<string>& spamlist);
void check(string emailToCheck, ourvector<string>& spamlist);
void filter(string fileName, string outputFileName, ourvector<string>& spamlist);
string getEmail(string tempLine);

//
//getCommand:
//this asks for user input, gets it and then calls the apropriate function 
//

void getCommand(){
    string command;
    ourvector<string> spamlist;
    
    while(command != "#"){
        cout << "Enter command or # to exit> ";
        getline(cin, command);
        int index = command.find(" ");
        if(command.substr(0, index) == "load"){
           load(command.substr(index+1), spamlist);
        }
        else if(command == "display"){
            display(spamlist);
        }
        else if(command.substr(0, index) == "check"){
            check(command.substr(index+1), spamlist);
        }
        else if(command.substr(0, index) == "filter"){
            command = command.substr(index+1);
            index = command.find(" ");
            filter(command.substr(0, index), command.substr(index+1), spamlist);
        }
        else if(command == "#"){
            
        }
        else{
            cout << "**invalid command" << endl;
        }
        cout << endl;
    }
}


//
//findDomainSpam:
//
//takes in a string from spam file and returns the domain of email
//

string findDomainSpam(string line){
    int index = line.find(":");
    return line.substr(0, index);
}



//
//findAddressSpam:
//
//takes in a string from spam file and returns the address of email 
//

string findAddressSpam(string line){
    int index = line.find(":");
    return line.substr(index+1);
}


//
//findDomainEmail:
//
//takes in a string with regular email and returns the domain of email 
//

string findDomainEmail(string line){
    int indexSpace = line.find(" ");
    line = line.substr(indexSpace+1);
    int indexAt = line.find("@");
    indexSpace = line.find(" ");
    return line.substr(indexAt+1, indexSpace);
}


//
//findAddressEmail:
//
//takes in a string with regular email and returns the address of email 
//

string findAddressEmail(string line){
    int indexAt = line.find("@");
    return line.substr(0, indexAt);
}



//
//load:
//
//this function opens a file with spam emails and loads them into outvector
//

void load(string filename, ourvector<string> &myEmails){
    
    if(myEmails.size()>0){   //
        myEmails.clear();    // makes sure to wipe the previous spamlist every time the user enters a new one
    }                        //
    
    ifstream inFS;
    inFS.open(filename);
    
    if(!inFS.is_open()){
        cout << "**Error, unable to open '" << filename << "'" << endl;
    }
    
    else{
    string tempLine;
    while(!inFS.eof()){
        getline(inFS, tempLine);                // read the file and
            if(!inFS.fail()){                   // put the emails
               myEmails.push_back(tempLine);    // into the
            }                                   // vector
        }
        cout << "Loading '" << filename << "'" << endl;
        cout << "# of spam entries: " << myEmails.size() << endl;
    }  
}

//
//display:
//
//this function displays all the emails in spam vector
//

void display(ourvector<string> &spamlist){
    for(int i = 0; i < spamlist.size(); ++i){
        cout << spamlist[i] << endl;
    }
}

//
//check:
//
//this function calls isSpam function and prints "spam"/"not spam" if the function returns true/fale
//

void check(string emailToCheck, ourvector<string>& spamlist){
    if(isSpam(emailToCheck, spamlist)){
        cout << emailToCheck << " is spam" << endl;
    }
    else{
        cout << emailToCheck << " is not spam" << endl;
    }
}

//
//isSpam:
//
//this function uses binary search to find if the given email is on the spamlist
//returns true if email is on spamlist, returns false if email is not on spamlist
//

bool isSpam(string emailToCheck, ourvector<string>& spamlist){
    string middle;
    string emailSpamFormat = findDomainEmail(emailToCheck) + ":*";  //use this to search for the email with star
    
    
    int mid = 0;
    int low = 0;
    int high = spamlist.size()-1;
    
    
    while (high >= low){
        mid = (high+low)/2;
        middle = spamlist[mid];
        
        if (middle < emailSpamFormat){                    //this is a binary search
            low = mid + 1;                                //for domain that has stars in it
        }                                                 //compares to find if the domain of email being checked has a * on spamlist
        else if (middle > emailSpamFormat){
            high = mid - 1;
        }
        else {
            return true;
        }
    }
    
    mid = 0;
    low = 0;
    high = spamlist.size()-1;
    
    
    while (high >= low){
        mid = (high+low)/2;
        middle = spamlist[mid];
        
        if (findDomainSpam(middle) < findDomainEmail(emailToCheck)){
            low = mid + 1;
        }
        else if (findDomainSpam(middle) > findDomainEmail(emailToCheck)){
            high = mid - 1;
        }
        else {
            if(findAddressSpam(middle) < findAddressEmail(emailToCheck)){
                low = mid + 1;
            }
            else if(findAddressSpam(middle) > findAddressEmail(emailToCheck)){
                high = mid - 1;
            }
            else {
                return true;
            }
        }//end else
    }//end while
    return false;
}

//
//filter:
//
//this function opens a file with emails, reads it
//compares each email in the file with the spamlist
//and uploads the emails that passed the check to a new text file
//

void filter(string fileName, string outputFileName, ourvector<string>& spamlist){
    ifstream inFS;
    inFS.open(fileName);
    
    if(!inFS.is_open()){
        cout << "**Error, unable to open '" << fileName << "'" << endl;
    }
    
    else{
        
    int noOfEmails = 0;
    int noOfNonSpam = 0;    
     
    string tempLine;
    ofstream outFS;
    outFS.open(outputFileName);
    while(!inFS.eof()){
        getline(inFS, tempLine);
            if(!inFS.fail()){
                noOfEmails++;
                if(!isSpam(getEmail(tempLine), spamlist)){
                    outFS << tempLine << endl;
                    ++noOfNonSpam;
                }
            }
        }
        cout << "# emails processed: " << noOfEmails << endl;
        cout << "# non-spam emails: " << noOfNonSpam << endl;
        outFS.close();
    }
}

//
//getEmail:
//
//this function gets a line from the filter method
//and returns only the email from this line
//

string getEmail(string tempLine){
    int index = tempLine.find(" ");
    tempLine = tempLine.substr(index+1);
    index = tempLine.find(" ");
    return tempLine.substr(0, index);
}




int main(){
    cout << "** Welcome to spam filtering app **" << endl;
    getCommand();
    return 0;
}